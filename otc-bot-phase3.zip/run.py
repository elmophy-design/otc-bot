"""Run the OTC Intelligence admin API."""
import uvicorn

if __name__ == "__main__":
    uvicorn.run("src.web.api:app", host="127.0.0.1", port=8000, reload=False)
